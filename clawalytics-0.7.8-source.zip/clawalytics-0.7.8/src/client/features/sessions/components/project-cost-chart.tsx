import { useMemo } from 'react'
import { X } from 'lucide-react'
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'
import type { ProjectBreakdown } from '@/lib/api'
import { useCurrency } from '@/context/currency-provider'
import { useLocale } from '@/context/locale-provider'
import { useChartColors } from '@/hooks/use-chart-colors'
import { Badge } from '@/components/ui/badge'

interface ProjectCostChartProps {
  data: ProjectBreakdown[]
  activeProject: string | undefined
  onProjectClick: (project: string) => void
}

const DEFAULT_COLORS = [
  'oklch(0.646 0.222 41.116)',
  'oklch(0.6 0.118 184.704)',
  'oklch(0.398 0.07 227.392)',
  'oklch(0.828 0.189 84.429)',
  'oklch(0.769 0.188 70.08)',
  'oklch(0.488 0.243 264.376)',
]

function formatProjectName(path: string | undefined, fallback: string): string {
  const value = path?.trim()
  if (!value) return fallback

  const parts = value.split('-')
  return (parts[parts.length - 1] || value).toUpperCase()
}

interface CustomTickProps {
  x?: number | string
  y?: number | string
  payload?: { value: string }
}

function CustomYAxisTick({ x, y, payload }: CustomTickProps) {
  if (!payload) return null

  return (
    <text
      x={Number(x)}
      y={Number(y)}
      dy={4}
      textAnchor='end'
      fill='hsl(var(--foreground))'
      style={{ fontFamily: '"Jersey 10", sans-serif', fontSize: '14px' }}
    >
      {payload.value}
    </text>
  )
}

export function ProjectCostChart({
  data,
  activeProject,
  onProjectClick,
}: ProjectCostChartProps) {
  const { locale, text } = useLocale()
  const { formatCurrency, formatCurrencyPrecise } = useCurrency()
  const colors = useChartColors()
  const numberLocale = locale === 'zh' ? 'zh-CN' : 'en-US'
  const unknownProjectLabel = text('未知项目', 'Unknown Project')

  const chartColors = useMemo(
    () => [
      colors.chart1 || DEFAULT_COLORS[0],
      colors.chart2 || DEFAULT_COLORS[1],
      colors.chart3 || DEFAULT_COLORS[2],
      colors.chart4 || DEFAULT_COLORS[3],
      colors.chart5 || DEFAULT_COLORS[4],
      colors.primary || DEFAULT_COLORS[5],
    ],
    [colors]
  )

  const getBarColor = (index: number) => chartColors[index % chartColors.length]

  const chartData = useMemo(
    () =>
      data
        .filter((item) => item.totalCost > 0 || item.sessionCount > 0)
        .map((item) => ({
          name: formatProjectName(item.project, unknownProjectLabel),
          project: item.project,
          cost: item.totalCost,
          sessions: item.sessionCount,
          inputTokens: item.totalInputTokens,
          outputTokens: item.totalOutputTokens,
        })),
    [data, unknownProjectLabel]
  )

  if (chartData.length === 0) {
    return (
      <div className='flex h-[200px] items-center justify-center px-4 text-center text-muted-foreground'>
        {text('暂无项目数据。', 'No project data available yet.')}
      </div>
    )
  }

  const chartHeight = Math.max(200, chartData.length * 28 + 40)

  return (
    <div>
      {activeProject && (
        <div className='mb-3 flex items-center gap-2'>
          <span className='text-sm text-muted-foreground'>
            {text('按项目筛选：', 'Filtered by:')}
          </span>
          <Badge
            variant='secondary'
            className='cursor-pointer gap-1'
            onClick={() => onProjectClick(activeProject)}
          >
            {formatProjectName(activeProject, unknownProjectLabel)}
            <X className='h-3 w-3' />
          </Badge>
        </div>
      )}
      <ResponsiveContainer width='100%' height={chartHeight}>
        <BarChart
          data={chartData}
          layout='vertical'
          margin={{ top: 10, right: 10, left: 0, bottom: 0 }}
        >
          <CartesianGrid
            strokeDasharray='3 3'
            horizontal
            vertical={false}
            stroke='hsl(var(--border))'
          />
          <XAxis
            type='number'
            stroke='hsl(var(--muted-foreground))'
            fontSize={11}
            tickLine={false}
            axisLine={false}
            tickFormatter={formatCurrency}
          />
          <YAxis
            type='category'
            dataKey='name'
            tickLine={false}
            axisLine={false}
            width={130}
            interval={0}
            tick={CustomYAxisTick}
          />
          <Tooltip
            content={({ active, payload }) => {
              if (active && payload && payload.length) {
                const item = payload[0].payload as (typeof chartData)[0]

                return (
                  <div className='min-w-[180px] rounded-lg border bg-background p-3 shadow-md'>
                    <div className='mb-2 font-jersey text-base'>
                      {item.name}
                    </div>
                    <div className='space-y-1.5'>
                      <div className='flex items-center justify-between gap-4'>
                        <span className='text-xs text-muted-foreground'>
                          {text('成本', 'Cost')}
                        </span>
                        <span className='font-mono text-sm font-medium'>
                          {formatCurrencyPrecise(item.cost)}
                        </span>
                      </div>
                      <div className='flex items-center justify-between gap-4'>
                        <span className='text-xs text-muted-foreground'>
                          {text('会话', 'Sessions')}
                        </span>
                        <span className='font-mono text-sm font-medium'>
                          {item.sessions.toLocaleString(numberLocale)}
                        </span>
                      </div>
                      <div className='flex items-center justify-between gap-4 border-t pt-1.5 text-xs text-muted-foreground'>
                        <span>
                          {(item.inputTokens / 1000).toFixed(1)}K{' '}
                          {text('输入', 'in')}
                        </span>
                        <span>
                          {(item.outputTokens / 1000).toFixed(1)}K{' '}
                          {text('输出', 'out')}
                        </span>
                      </div>
                    </div>
                  </div>
                )
              }

              return null
            }}
          />
          <Bar
            isAnimationActive={false}
            dataKey='cost'
            radius={[0, 4, 4, 0]}
            maxBarSize={22}
            cursor='pointer'
            onClick={(_entry, index) => {
              if (typeof index === 'number' && chartData[index]) {
                onProjectClick(chartData[index].project)
              }
            }}
          >
            {chartData.map((_, index) => (
              <Cell key={`cell-${index}`} fill={getBarColor(index)} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  )
}
