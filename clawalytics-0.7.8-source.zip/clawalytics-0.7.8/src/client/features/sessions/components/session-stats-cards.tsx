import { Activity, DollarSign, TrendingUp, FolderOpen } from 'lucide-react'
import type { SessionStats } from '@/lib/api'
import { formatNumber } from '@/lib/format'
import { useCurrency } from '@/context/currency-provider'
import { useLocale } from '@/context/locale-provider'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'

interface SessionStatsCardsProps {
  stats: SessionStats | undefined
  isLoading: boolean
}

function formatProjectName(path: string | undefined, fallback: string): string {
  const value = path?.trim()
  if (!value) return fallback

  const parts = value.split('-')
  return parts[parts.length - 1] || value
}

export function SessionStatsCards({
  stats,
  isLoading,
}: SessionStatsCardsProps) {
  const { text } = useLocale()
  const { formatCurrency } = useCurrency()

  return (
    <div className='grid gap-4 sm:grid-cols-2 lg:grid-cols-4'>
      <Card className='relative overflow-hidden'>
        <div className='absolute top-0 right-0 h-24 w-24 rounded-bl-full bg-gradient-to-bl from-primary/10 to-transparent' />
        <CardHeader className='flex flex-row items-center justify-between space-y-0 pb-2'>
          <CardTitle className='text-sm font-medium'>
            {text('总会话数', 'Total Sessions')}
          </CardTitle>
          <div className='rounded-full bg-primary/10 p-2'>
            <Activity className='h-4 w-4 text-primary' />
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <>
              <Skeleton className='mb-1 h-8 w-16' />
              <Skeleton className='h-4 w-24' />
            </>
          ) : (
            <>
              <div className='text-2xl font-bold text-primary'>
                {formatNumber(stats?.totalSessions ?? 0)}
              </div>
              <p className='text-xs text-muted-foreground'>
                {stats?.totalSessionsThisMonth ?? 0}{' '}
                {text('本月', 'This month')}
              </p>
            </>
          )}
        </CardContent>
      </Card>

      <Card className='relative overflow-hidden'>
        <div className='absolute top-0 right-0 h-24 w-24 rounded-bl-full bg-gradient-to-bl from-primary/10 to-transparent' />
        <CardHeader className='flex flex-row items-center justify-between space-y-0 pb-2'>
          <CardTitle className='text-sm font-medium'>
            {text('总成本', 'Total Cost')}
          </CardTitle>
          <div className='rounded-full bg-primary/10 p-2'>
            <DollarSign className='h-4 w-4 text-primary' />
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <>
              <Skeleton className='mb-1 h-8 w-24' />
              <Skeleton className='h-4 w-32' />
            </>
          ) : (
            <>
              <div className='text-2xl font-bold text-primary'>
                {formatCurrency(stats?.totalCost ?? 0)}
              </div>
              <p className='text-xs text-muted-foreground'>
                {text('全部会话累计', 'Across all sessions')}
              </p>
            </>
          )}
        </CardContent>
      </Card>

      <Card className='relative overflow-hidden'>
        <div className='absolute top-0 right-0 h-24 w-24 rounded-bl-full bg-gradient-to-bl from-primary/10 to-transparent' />
        <CardHeader className='flex flex-row items-center justify-between space-y-0 pb-2'>
          <CardTitle className='text-sm font-medium'>
            {text('平均每会话成本', 'Avg Cost / Session')}
          </CardTitle>
          <div className='rounded-full bg-primary/10 p-2'>
            <TrendingUp className='h-4 w-4 text-primary' />
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <>
              <Skeleton className='mb-1 h-8 w-20' />
              <Skeleton className='h-4 w-28' />
            </>
          ) : (
            <>
              <div className='text-2xl font-bold text-primary'>
                {formatCurrency(stats?.avgCostPerSession ?? 0)}
              </div>
              <p className='text-xs text-muted-foreground'>
                {text('按会话平均', 'Per session average')}
              </p>
            </>
          )}
        </CardContent>
      </Card>

      <Card className='relative overflow-hidden'>
        <div className='absolute top-0 right-0 h-24 w-24 rounded-bl-full bg-gradient-to-bl from-primary/10 to-transparent' />
        <CardHeader className='flex flex-row items-center justify-between space-y-0 pb-2'>
          <CardTitle className='text-sm font-medium'>
            {text('最活跃项目', 'Most Active Project')}
          </CardTitle>
          <div className='rounded-full bg-primary/10 p-2'>
            <FolderOpen className='h-4 w-4 text-primary' />
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <>
              <Skeleton className='mb-1 h-8 w-24' />
              <Skeleton className='h-4 w-20' />
            </>
          ) : (
            <>
              <div className='truncate text-2xl font-bold text-primary'>
                {stats?.mostActiveProject
                  ? formatProjectName(
                      stats.mostActiveProject.project,
                      text('未知项目', 'Unknown Project')
                    )
                  : text('暂无', 'N/A')}
              </div>
              <p className='text-xs text-muted-foreground'>
                {stats?.mostActiveProject
                  ? `${stats.mostActiveProject.sessionCount} ${text('个会话', 'sessions')}`
                  : text('暂无数据', 'No data')}
              </p>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
