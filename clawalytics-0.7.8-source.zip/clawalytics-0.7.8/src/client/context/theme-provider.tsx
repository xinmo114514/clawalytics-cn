import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react'
import { getCookie, setCookie, removeCookie } from '@/lib/cookies'

export type ColorTheme =
  | 'blue'
  | 'purple'
  | 'green'
  | 'orange'
  | 'pink'
  | 'windows'
type Theme = 'dark' | 'light' | 'system'
type ResolvedTheme = Exclude<Theme, 'system'>

const DEFAULT_THEME = 'system'
const DEFAULT_COLOR_THEME: ColorTheme = 'windows'
const THEME_COOKIE_NAME = 'vite-ui-theme'
const COLOR_THEME_COOKIE_NAME = 'vite-ui-color-theme'
const THEME_COOKIE_MAX_AGE = 60 * 60 * 24 * 365

export const colorThemes: { value: ColorTheme; zh: string; en: string }[] = [
  { value: 'windows', zh: '跟随 Windows', en: 'Windows' },
  { value: 'blue', zh: '蓝色', en: 'Blue' },
  { value: 'purple', zh: '紫色', en: 'Purple' },
  { value: 'green', zh: '绿色', en: 'Green' },
  { value: 'orange', zh: '橙色', en: 'Orange' },
  { value: 'pink', zh: '粉色', en: 'Pink' },
]

type ThemeProviderProps = {
  children: React.ReactNode
  defaultTheme?: Theme
  defaultColorTheme?: ColorTheme
  storageKey?: string
}

type ThemeProviderState = {
  defaultTheme: Theme
  defaultColorTheme: ColorTheme
  resolvedTheme: ResolvedTheme
  theme: Theme
  setTheme: (theme: Theme) => void
  resetTheme: () => void
  colorTheme: ColorTheme
  setColorTheme: (colorTheme: ColorTheme) => void
  resetColorTheme: () => void
}

const initialState: ThemeProviderState = {
  defaultTheme: DEFAULT_THEME,
  defaultColorTheme: DEFAULT_COLOR_THEME,
  resolvedTheme: 'light',
  theme: DEFAULT_THEME,
  setTheme: () => null,
  resetTheme: () => null,
  colorTheme: DEFAULT_COLOR_THEME,
  setColorTheme: () => null,
  resetColorTheme: () => null,
}

const ThemeContext = createContext<ThemeProviderState>(initialState)

export function ThemeProvider({
  children,
  defaultTheme = DEFAULT_THEME,
  defaultColorTheme = DEFAULT_COLOR_THEME,
  storageKey = THEME_COOKIE_NAME,
  ...props
}: ThemeProviderProps) {
  const [theme, _setTheme] = useState<Theme>(
    () => (getCookie(storageKey) as Theme) || defaultTheme
  )

  const [colorTheme, _setColorTheme] = useState<ColorTheme>(() => {
    const savedColor = getCookie(COLOR_THEME_COOKIE_NAME) as ColorTheme
    return colorThemes.some((c) => c.value === savedColor)
      ? savedColor
      : defaultColorTheme
  })

  const [windowsAccentColor, setWindowsAccentColor] = useState<string | null>(
    null
  )

  const resolvedTheme = useMemo((): ResolvedTheme => {
    if (theme === 'system') {
      return window.matchMedia('(prefers-color-scheme: dark)').matches
        ? 'dark'
        : 'light'
    }
    return theme as ResolvedTheme
  }, [theme])

  useEffect(() => {
    const root = window.document.documentElement
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)')

    const applyTheme = (currentResolvedTheme: ResolvedTheme) => {
      root.classList.remove('light', 'dark')
      root.classList.add(currentResolvedTheme)
    }

    const handleChange = () => {
      if (theme === 'system') {
        const systemTheme = mediaQuery.matches ? 'dark' : 'light'
        applyTheme(systemTheme)
      }
    }

    applyTheme(resolvedTheme)

    mediaQuery.addEventListener('change', handleChange)

    return () => mediaQuery.removeEventListener('change', handleChange)
  }, [theme, resolvedTheme])

  useEffect(() => {
    if (!window.electronAPI) {
      return
    }

    let isMounted = true

    window.electronAPI.getWindowsAccentColor().then((color) => {
      if (isMounted && color) {
        setWindowsAccentColor(color)
      }
    })

    const cleanup = window.electronAPI.onWindowsAccentColorChanged((color) => {
      if (isMounted) {
        setWindowsAccentColor(color)
      }
    })

    return () => {
      isMounted = false
      cleanup()
    }
  }, [])

  useEffect(() => {
    const root = window.document.documentElement
    colorThemes.forEach((c) => root.classList.remove(`color-${c.value}`))
    root.classList.add(`color-${colorTheme}`)

    if (colorTheme === 'windows' && windowsAccentColor) {
      root.style.setProperty('--windows-accent', windowsAccentColor)
      root.style.setProperty('--windows-accent-dark', windowsAccentColor)
    }
  }, [colorTheme, resolvedTheme, windowsAccentColor])

  const setTheme = useCallback(
    (theme: Theme) => {
      setCookie(storageKey, theme, THEME_COOKIE_MAX_AGE)
      _setTheme(theme)
    },
    [storageKey]
  )

  const resetTheme = useCallback(() => {
    removeCookie(storageKey)
    _setTheme(DEFAULT_THEME)
  }, [storageKey])

  const setColorTheme = useCallback((colorTheme: ColorTheme) => {
    setCookie(COLOR_THEME_COOKIE_NAME, colorTheme, THEME_COOKIE_MAX_AGE)
    _setColorTheme(colorTheme)
  }, [])

  const resetColorTheme = useCallback(() => {
    removeCookie(COLOR_THEME_COOKIE_NAME)
    _setColorTheme(DEFAULT_COLOR_THEME)
  }, [])

  const contextValue = useMemo(
    () => ({
      defaultTheme,
      defaultColorTheme,
      resolvedTheme,
      resetTheme,
      theme,
      setTheme,
      colorTheme,
      setColorTheme,
      resetColorTheme,
    }),
    [
      defaultTheme,
      defaultColorTheme,
      resolvedTheme,
      resetTheme,
      theme,
      setTheme,
      colorTheme,
      setColorTheme,
      resetColorTheme,
    ]
  )

  return (
    <ThemeContext value={contextValue} {...props}>
      {children}
    </ThemeContext>
  )
}

export const useTheme = () => {
  const context = useContext(ThemeContext)

  if (!context) throw new Error('useTheme must be used within a ThemeProvider')

  return context
}
