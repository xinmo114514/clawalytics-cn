import { useMemo } from 'react'
import {
  Cell,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
} from 'recharts'
import type { Agent } from '@/lib/api'
import { useCurrency } from '@/context/currency-provider'
import { useLocale } from '@/context/locale-provider'
import { useChartColors } from '@/hooks/use-chart-colors'

interface AgentDistributionChartProps {
  agents: Agent[]
}

export function AgentDistributionChart({
  agents,
}: AgentDistributionChartProps) {
  const { text } = useLocale()
  const { formatCurrencyPrecise } = useCurrency()
  const colors = useChartColors()
  const chartColors = useMemo(
    () => [
      colors.chart1 || 'var(--chart-1)',
      colors.chart2 || 'var(--chart-2)',
      colors.chart3 || 'var(--chart-3)',
      colors.chart4 || 'var(--chart-4)',
      colors.chart5 || 'var(--chart-5)',
      colors.primary || 'var(--primary)',
    ],
    [
      colors.chart1,
      colors.chart2,
      colors.chart3,
      colors.chart4,
      colors.chart5,
      colors.primary,
    ]
  )
  const totalCost = useMemo(
    () => agents.reduce((acc, agent) => acc + agent.total_cost, 0),
    [agents]
  )

  const chartData = useMemo(
    () =>
      agents
        .filter((agent) => agent.total_cost > 0)
        .sort((a, b) => b.total_cost - a.total_cost)
        .slice(0, 6)
        .map((agent, idx) => ({
          name: agent.name,
          value: agent.total_cost,
          percentage: totalCost > 0 ? (agent.total_cost / totalCost) * 100 : 0,
          fill: chartColors[idx % chartColors.length],
          sessions: agent.session_count,
          inputTokens: agent.total_input_tokens,
          outputTokens: agent.total_output_tokens,
        })),
    [agents, totalCost, chartColors]
  )

  if (chartData.length === 0) {
    return (
      <div className='flex h-[300px] items-center justify-center px-4 text-center text-muted-foreground'>
        {text(
          '暂无数据。代理活跃后，这里会显示成本分布。',
          'No data yet. The distribution will appear once agents are active.'
        )}
      </div>
    )
  }

  return (
    <ResponsiveContainer width='100%' height={300}>
      <PieChart>
        <Pie
          isAnimationActive={false}
          data={chartData}
          cx='50%'
          cy='45%'
          innerRadius={55}
          outerRadius={90}
          paddingAngle={2}
          dataKey='value'
          nameKey='name'
          strokeWidth={2}
          stroke='hsl(var(--background))'
        >
          {chartData.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={entry.fill} />
          ))}
        </Pie>
        <Tooltip
          content={({ active, payload }) => {
            if (active && payload && payload.length) {
              const item = payload[0].payload as (typeof chartData)[0]

              return (
                <div className='min-w-[180px] rounded-lg border bg-background p-3 shadow-md'>
                  <div className='mb-2 max-w-[200px] truncate text-sm font-medium'>
                    {item.name}
                  </div>
                  <div className='space-y-1.5'>
                    <div className='flex items-center justify-between gap-4'>
                      <span className='text-xs text-muted-foreground'>
                        {text('成本', 'Cost')}
                      </span>
                      <span className='font-mono text-sm font-medium'>
                        {formatCurrencyPrecise(item.value)}
                      </span>
                    </div>
                    <div className='flex items-center justify-between gap-4'>
                      <span className='text-xs text-muted-foreground'>
                        {text('占比', 'Share')}
                      </span>
                      <span className='font-mono text-sm font-medium'>
                        {item.percentage.toFixed(1)}%
                      </span>
                    </div>
                    <div className='flex items-center justify-between gap-4'>
                      <span className='text-xs text-muted-foreground'>
                        {text('会话数', 'Sessions')}
                      </span>
                      <span className='font-mono text-sm font-medium'>
                        {item.sessions}
                      </span>
                    </div>
                    <div className='flex items-center justify-between gap-4 border-t pt-1.5 text-xs text-muted-foreground'>
                      <span>
                        {(item.inputTokens / 1000).toFixed(1)}K{' '}
                        {text('输入', 'in')}
                      </span>
                      <span>
                        {(item.outputTokens / 1000).toFixed(1)}K{' '}
                        {text('输出', 'out')}
                      </span>
                    </div>
                  </div>
                </div>
              )
            }

            return null
          }}
        />
        <Legend
          verticalAlign='bottom'
          height={36}
          iconType='circle'
          iconSize={8}
          formatter={(value: string) => (
            <span className='text-xs text-muted-foreground'>{value}</span>
          )}
        />
      </PieChart>
    </ResponsiveContainer>
  )
}

AgentDistributionChart.displayName = 'AgentDistributionChart'
