/**
 * OpenClaw Gateway Log Parser
 *
 * Parses JSON Lines logs from /tmp/openclaw/openclaw-YYYY-MM-DD.log
 * Each line contains token usage, cost, and metadata for API calls.
 */
import path from 'path'
import chokidar, { type FSWatcher } from 'chokidar'
// ============================================
// Connection Event Watching (for security)
// ============================================

import fs from 'fs'
import { convertUsdToCny } from '../../lib/currency.js'
import { calculateCost, identifyProvider } from '../costs.js'

// ============================================
// Interfaces
// ============================================

/**
 * Raw log entry structure from OpenClaw gateway logs
 */
export interface OpenClawLogEntry {
  timestamp: string
  level: string // "INFO", "WARN", "ERROR", "DEBUG"
  subsystem?: string // "api", "gateway", "auth", etc.
  message?: string

  // Model and token data (present for API calls)
  model?: string // "anthropic/claude-opus-4-5", "openai/gpt-4o", etc.
  tokens?: {
    input?: number
    output?: number
    cache_read?: number
    cache_write?: number
  }
  cost?: number // USD cost (when available from provider)
  duration_ms?: number
  context_tokens?: number

  // Channel/session info
  channel?: string // "whatsapp", "telegram", "slack", etc.
  session_id?: string
  agent_id?: string

  // Connection events (for security monitoring)
  event?: string // "connection", "disconnection", "auth_success", etc.
  device_id?: string
  ip?: string
  error?: string
}

/**
 * Parsed result with normalized data for database storage
 */
export interface ParsedGatewayLogResult {
  timestamp: string
  provider: string
  model: string
  inputTokens: number
  outputTokens: number
  cacheCreationTokens: number
  cacheReadTokens: number
  cost: number
  cacheSavings: number
  durationMs: number
  channel: string | null
  sessionId: string | null
  agentId: string | null
  rawEntry: OpenClawLogEntry
}

/**
 * Connection event for security monitoring
 */
export interface ConnectionEvent {
  timestamp: string
  event: string
  deviceId: string | null
  ip: string | null
  message: string | null
  error: string | null
  level: string
}

function nonNegativeFiniteNumber(value: unknown): number | undefined {
  return typeof value === 'number' && Number.isFinite(value) && value >= 0
    ? value
    : undefined
}

function normalizeTimestamp(value: unknown): string | null {
  if (typeof value !== 'string') return null
  const date = new Date(value)
  return Number.isNaN(date.getTime()) ? null : date.toISOString()
}

// ============================================
// Parsing Functions
// ============================================

/**
 * Parse a single line from OpenClaw gateway logs
 * Returns token/cost data if present, null otherwise
 */
export function parseGatewayLogLine(
  line: string
): ParsedGatewayLogResult | null {
  if (!line.trim()) {
    return null
  }

  let entry: OpenClawLogEntry
  try {
    entry = JSON.parse(line) as OpenClawLogEntry
  } catch {
    // Not JSON, skip
    return null
  }

  // Only process entries with token data
  if (!entry.tokens && !entry.model) {
    return null
  }

  // Extract provider and model from "provider/model" format
  const { provider, model } = parseModelIdentifier(
    entry.model || 'unknown/unknown'
  )

  // Extract token counts
  const inputTokens = nonNegativeFiniteNumber(entry.tokens?.input) ?? 0
  const outputTokens = nonNegativeFiniteNumber(entry.tokens?.output) ?? 0
  const cacheReadTokens = nonNegativeFiniteNumber(entry.tokens?.cache_read) ?? 0
  const cacheCreationTokens =
    nonNegativeFiniteNumber(entry.tokens?.cache_write) ?? 0

  // Skip entries with no tokens
  if (
    inputTokens === 0 &&
    outputTokens === 0 &&
    cacheReadTokens === 0 &&
    cacheCreationTokens === 0
  ) {
    return null
  }

  const providerReportedCost =
    typeof entry.cost === 'number' &&
    Number.isFinite(entry.cost) &&
    entry.cost >= 0
      ? convertUsdToCny(entry.cost)
      : undefined

  // Always calculate from our pricing data when we need cache savings or
  // when a provider adapter is known to emit placeholder/non-final costs.
  const costResult = calculateCost(
    provider,
    model,
    {
      inputTokens,
      outputTokens,
      cacheCreationTokens,
      cacheReadTokens,
    },
    {
      suppressMissingPricingWarning: Boolean(
        providerReportedCost !== undefined
      ),
    }
  )

  // Prefer the cost already emitted by OpenClaw. The local catalog is a
  // fallback for older gateway records without a cost field.
  const cost = providerReportedCost ?? costResult.totalCost
  const cacheSavings = costResult.cacheSavings
  const timestamp = normalizeTimestamp(entry.timestamp)
  if (!timestamp) {
    return null
  }

  return {
    timestamp,
    provider,
    model,
    inputTokens,
    outputTokens,
    cacheCreationTokens,
    cacheReadTokens,
    cost,
    cacheSavings,
    durationMs: nonNegativeFiniteNumber(entry.duration_ms) ?? 0,
    channel: entry.channel || null,
    sessionId: entry.session_id || null,
    agentId: entry.agent_id || null,
    rawEntry: entry,
  }
}

/**
 * Parse connection event from gateway logs (for security monitoring)
 */
export function parseConnectionEvent(line: string): ConnectionEvent | null {
  if (!line.trim()) {
    return null
  }

  let entry: OpenClawLogEntry
  try {
    entry = JSON.parse(line) as OpenClawLogEntry
  } catch {
    return null
  }

  // Only process connection-related events
  if (!entry.event) {
    return null
  }

  const connectionEvents = [
    'connection',
    'disconnection',
    'auth_success',
    'auth_failure',
    'device_paired',
    'device_unpaired',
  ]
  if (!connectionEvents.includes(entry.event)) {
    return null
  }

  return {
    timestamp: entry.timestamp || new Date().toISOString(),
    event: entry.event,
    deviceId: entry.device_id || null,
    ip: entry.ip || null,
    message: entry.message || null,
    error: entry.error || null,
    level: entry.level || 'INFO',
  }
}

/**
 * Parse model identifier from "provider/model" format
 * Examples:
 *   "anthropic/claude-opus-4-5" -> { provider: "anthropic", model: "claude-opus-4-5" }
 *   "openrouter/anthropic/claude-opus-4-5" -> { provider: "openrouter", model: "anthropic/claude-opus-4-5" }
 *   "gpt-4o" -> { provider: "unknown", model: "gpt-4o" }
 */
export function parseModelIdentifier(modelId: string): {
  provider: string
  model: string
} {
  if (!modelId || modelId === 'unknown') {
    return { provider: 'unknown', model: 'unknown' }
  }

  const slashIndex = modelId.indexOf('/')

  if (slashIndex === -1) {
    // No provider prefix, try to infer
    return {
      provider: inferProvider(modelId),
      model: modelId,
    }
  }

  const provider = modelId.substring(0, slashIndex)
  const model = modelId.substring(slashIndex + 1)

  return { provider, model }
}

/**
 * Infer provider from model name when not explicitly provided. Delegates to
 * the canonical identifier in costs.ts so every model name is bucketed the
 * same way regardless of which parser first saw it.
 */
function inferProvider(model: string): string {
  return identifyProvider(model)
}

/**
 * Parse multiple log lines and return all valid results
 */
export function parseGatewayLogLines(
  content: string
): ParsedGatewayLogResult[] {
  const lines = content.split('\n')
  const results: ParsedGatewayLogResult[] = []

  for (const line of lines) {
    const result = parseGatewayLogLine(line)
    if (result) {
      results.push(result)
    }
  }

  return results
}

// ============================================
// Gateway Log Entry (for security monitoring)
// ============================================

/**
 * Legacy gateway log entry format for security monitoring
 * Used by security-watcher.ts for connection events
 */
export interface GatewayLogEntry {
  timestamp: string
  level: string
  event: string
  deviceId?: string
  ip?: string
  message?: string
  error?: string
}

const securityFilePositions = new Map<string, number>()
let securityGatewayWatcher: FSWatcher | null = null

/**
 * Watch gateway log files for connection events (security monitoring)
 */
export function watchGatewayLogs(
  logsPath: string,
  onEvent: (event: GatewayLogEntry) => void
): FSWatcher | null {
  if (!fs.existsSync(logsPath)) {
    console.log(`Gateway logs path does not exist: ${logsPath}`)
    return null
  }

  const globPattern = path.join(logsPath, 'openclaw-*.log')

  securityGatewayWatcher = chokidar.watch(globPattern, {
    persistent: true,
    ignoreInitial: false,
    awaitWriteFinish: {
      stabilityThreshold: 100,
      pollInterval: 50,
    },
  })

  securityGatewayWatcher.on('add', (filePath) => {
    processSecurityLogFile(filePath, onEvent)
  })

  securityGatewayWatcher.on('change', (filePath) => {
    processSecurityLogFileChanges(filePath, onEvent)
  })

  securityGatewayWatcher.on('error', (error) => {
    console.error('Error watching gateway logs for security:', error)
  })

  console.log(`Watching gateway logs for security events in: ${logsPath}`)
  return securityGatewayWatcher
}

/**
 * Stop watching gateway logs for security events
 */
export function stopGatewayWatcher(): void {
  if (securityGatewayWatcher) {
    securityGatewayWatcher.close()
    securityGatewayWatcher = null
    securityFilePositions.clear()
    console.log('Security gateway watcher stopped')
  }
}

function processSecurityLogFile(
  filePath: string,
  onEvent: (event: GatewayLogEntry) => void
): void {
  try {
    const stats = fs.statSync(filePath)
    const content = fs.readFileSync(filePath, 'utf-8')
    const lines = content.split('\n')

    for (const line of lines) {
      const event = parseConnectionEvent(line)
      if (event) {
        onEvent({
          timestamp: event.timestamp,
          level: event.level,
          event: event.event,
          deviceId: event.deviceId ?? undefined,
          ip: event.ip ?? undefined,
          message: event.message ?? undefined,
          error: event.error ?? undefined,
        })
      }
    }

    securityFilePositions.set(filePath, stats.size)
  } catch (error) {
    console.error(`Error processing security log ${filePath}:`, error)
  }
}

function processSecurityLogFileChanges(
  filePath: string,
  onEvent: (event: GatewayLogEntry) => void
): void {
  try {
    const stats = fs.statSync(filePath)
    const previousPosition = securityFilePositions.get(filePath) || 0

    if (stats.size <= previousPosition) {
      if (stats.size < previousPosition) {
        securityFilePositions.set(filePath, 0)
        processSecurityLogFile(filePath, onEvent)
      }
      return
    }

    const fd = fs.openSync(filePath, 'r')
    const newBytes = stats.size - previousPosition
    const buffer = Buffer.alloc(newBytes)
    fs.readSync(fd, buffer, 0, newBytes, previousPosition)
    fs.closeSync(fd)

    const newContent = buffer.toString('utf-8')
    const lines = newContent.split('\n')

    for (const line of lines) {
      const event = parseConnectionEvent(line)
      if (event) {
        onEvent({
          timestamp: event.timestamp,
          level: event.level,
          event: event.event,
          deviceId: event.deviceId ?? undefined,
          ip: event.ip ?? undefined,
          message: event.message ?? undefined,
          error: event.error ?? undefined,
        })
      }
    }

    securityFilePositions.set(filePath, stats.size)
  } catch (error) {
    console.error(`Error processing security log changes ${filePath}:`, error)
  }
}
