import { createAlert } from '../db/queries-security.js'
import { formatCny } from '../lib/currency.js'
import { getAnalyticsService } from './analytics-service.js'
import { formatLocalDate, localWindowStart } from '../analytics/analytics-index.js'

interface AnomalyResult {
  type: string
  severity: 'low' | 'medium' | 'high'
  message: string
  details: Record<string, unknown>
}

// Track known models to detect new ones
const knownModels = new Set<string>()
let lastCheckDate = ''
const MIN_DAILY_SPIKE_COST = 7
const MIN_MODEL_SPIKE_COST = 3.5

/**
 * Run anomaly detection checks.
 * Call this periodically (e.g., after processing log batches).
 */
export function detectAnomalies(): AnomalyResult[] {
  const anomalies: AnomalyResult[] = []

  const today = formatLocalDate(new Date())

  // Only run once per day to avoid spam
  if (lastCheckDate === today) return anomalies
  lastCheckDate = today

  // 1. Cost spike detection (7-day rolling average comparison)
  const costSpike = detectCostSpike()
  if (costSpike) anomalies.push(costSpike)

  // 2. Model spike detection
  const modelSpikes = detectModelSpikes()
  anomalies.push(...modelSpikes)

  // 3. New model detection
  const newModels = detectNewModels()
  anomalies.push(...newModels)

  // Create alerts for any anomalies found
  for (const anomaly of anomalies) {
    createAlert({
      type: `anomaly_${anomaly.type}`,
      severity: anomaly.severity,
      message: anomaly.message,
      details: JSON.stringify(anomaly.details),
    })
  }

  return anomalies
}

/**
 * Detect if today's spending significantly exceeds the rolling 7-day average.
 */
function detectCostSpike(): AnomalyResult | null {
  const svc = getAnalyticsService()
  const costs = svc.getDailyCosts(14)
  if (costs.length < 8) return null // Need enough data

  // Separate today from the previous 7 days
  const today = costs[costs.length - 1]
  const previous7 = costs.slice(-8, -1)

  if (previous7.length === 0) return null

  const avgCost =
    previous7.reduce((sum, d) => sum + d.total_cost, 0) / previous7.length

  if (avgCost <= 0) return null

  const ratio = today.total_cost / avgCost

  // Alert if today's cost is more than 3x the average
  if (ratio >= 3 && today.total_cost > MIN_DAILY_SPIKE_COST) {
    return {
      type: 'cost_spike',
      severity: ratio >= 5 ? 'high' : 'medium',
      message: `Daily cost spike: ${formatCny(today.total_cost)} is ${ratio.toFixed(1)}x your 7-day average (${formatCny(avgCost)})`,
      details: {
        todayCost: today.total_cost,
        averageCost: avgCost,
        ratio,
        date: today.date,
      },
    }
  }

  return null
}

/**
 * Detect if any single model's cost spiked significantly.
 */
function detectModelSpikes(): AnomalyResult[] {
  const anomalies: AnomalyResult[] = []
  const svc = getAnalyticsService()
  const today = svc.today()
  const windowStart = localWindowStart(new Date(), 7) // last 7 days inclusive
  const previousStart = localWindowStart(new Date(), 14) // previous 7 days

  const daily = svc.getModelDailyUsage(14)
  const recentByModel = new Map<string, number>()
  const previousByModel = new Map<string, number>()

  for (const entry of daily) {
    if (entry.date > today) continue
    const key = entry.provider + '/' + entry.model
    if (entry.date >= windowStart) {
      recentByModel.set(key, (recentByModel.get(key) ?? 0) + entry.cost)
    } else if (entry.date >= previousStart) {
      previousByModel.set(key, (previousByModel.get(key) ?? 0) + entry.cost)
    }
  }

  for (const [key, recentCost] of recentByModel) {
    const previousCost = previousByModel.get(key) ?? 0
    if (previousCost <= 0) continue
    const ratio = recentCost / previousCost
    if (ratio >= 3 && recentCost > MIN_MODEL_SPIKE_COST) {
      anomalies.push({
        type: 'model_spike',
        severity: 'medium',
        message: 'Model cost spike: ' + key + ' cost ' + formatCny(recentCost) + ' this week (' + ratio.toFixed(1) + 'x previous week)',
        details: {
          model: key,
          recentCost,
          previousCost,
          ratio,
        },
      })
    }
  }

  return anomalies
}

/**
 * Detect new models that haven't been seen before.
 */
function detectNewModels(): AnomalyResult[] {
  const anomalies: AnomalyResult[] = []
  const svc = getAnalyticsService()
  const currentModels = svc.getModelUsage(1)

  // Initialize known models from historical data on first run
  if (knownModels.size === 0) {
    const allModels = svc.getModelUsage(90)
    for (const m of allModels) {
      knownModels.add(`${m.provider}/${m.model}`)
    }
    return anomalies // Don't alert on first run
  }

  for (const model of currentModels) {
    const key = `${model.provider}/${model.model}`
    if (!knownModels.has(key)) {
      knownModels.add(key)
      anomalies.push({
        type: 'new_model',
        severity: 'low',
        message: `New model detected: ${key}`,
        details: {
          provider: model.provider,
          model: model.model,
          cost: model.cost,
          requestCount: model.request_count,
        },
      })
    }
  }

  return anomalies
}

/**
 * Reset anomaly detection state (useful for testing).
 */
export function resetAnomalyState(): void {
  knownModels.clear()
  lastCheckDate = ''
}
